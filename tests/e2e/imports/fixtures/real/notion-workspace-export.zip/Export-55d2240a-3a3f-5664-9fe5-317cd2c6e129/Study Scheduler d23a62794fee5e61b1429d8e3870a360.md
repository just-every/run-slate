# Study Scheduler

<aside>
<img src="Study%20Scheduler/Copy_of_misty_thinking_glitch.png" alt="Study%20Scheduler/Copy_of_misty_thinking_glitch.png" width="40px" />

Welcome home. See the [manual](Study%20Scheduler/manual%20c04b15e110da529aa74fd79a88362912.md) to get started.

</aside>

<aside>
<img src="https://fixture.example.test/icons/book-closed_blue.svg" alt="https://fixture.example.test/icons/book-closed_blue.svg" width="40px" /> **Courses**

[Untitled](Study%20Scheduler/Domains%20f982139c3a4e5c3cbdf00d1bb12d3933_all.csv)

filters: 
ywd~
</aside>

<aside>
<img src="https://fixture.example.test/icons/calendar_blue.svg" alt="https://fixture.example.test/icons/calendar_blue.svg" width="40px" />

[Untitled](Study%20Scheduler/Topics%20eb8a07e4a23a5c9694d80f1430967d8a_all.csv)

filters: 
type
sort: 
mastery: ascending

</aside>

- **⚠️ DO NOT DELETE. This stuff runs the template! ⚠️**
    
    [manual](Study%20Scheduler/manual%20c04b15e110da529aa74fd79a88362912.md)
    
    - 💾 OS
        
        [Topics](Study%20Scheduler/Topics%20eb8a07e4a23a5c9694d80f1430967d8a.md)
        
        [Domains](Study%20Scheduler/Domains%20f982139c3a4e5c3cbdf00d1bb12d3933.md)
        
        [Migration](Study%20Scheduler/Migration%2099ea03c81aaa59eb937a5ef58deeea8f.md)
        

---