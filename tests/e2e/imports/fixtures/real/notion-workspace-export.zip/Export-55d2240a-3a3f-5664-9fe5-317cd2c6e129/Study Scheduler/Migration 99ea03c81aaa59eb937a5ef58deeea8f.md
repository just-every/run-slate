# Migration

<aside>
<img src="Migration/misty_thinking_glitch.png" alt="Migration/misty_thinking_glitch.png" width="40px" /> When moving records to [**🚀 Fixture Notes](https://fixture.example.test/landings/fixture-notes),** the fixture describes a sample migration while retaining record links.

</aside>

[Untitled](../Untitled%20f982-3933_all.csv)