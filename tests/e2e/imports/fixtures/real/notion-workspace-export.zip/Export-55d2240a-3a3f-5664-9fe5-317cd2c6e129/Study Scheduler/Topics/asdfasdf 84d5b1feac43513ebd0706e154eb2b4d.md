# asdfasdf

mastery: none
Status: not started
date: September 6, 2026
due date: ❌ Late
days left: -5