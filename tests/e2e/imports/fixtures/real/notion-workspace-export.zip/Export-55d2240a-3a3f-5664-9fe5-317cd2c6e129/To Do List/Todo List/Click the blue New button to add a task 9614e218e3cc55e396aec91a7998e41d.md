# Click the blue New button to add a task

Due date: September 11, 2026
Status: Not started
Assignee: Alex