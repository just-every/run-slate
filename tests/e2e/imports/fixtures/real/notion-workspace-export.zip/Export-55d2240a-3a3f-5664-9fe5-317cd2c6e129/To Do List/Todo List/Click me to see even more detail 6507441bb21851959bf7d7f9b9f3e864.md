# Click me to see even more detail

Due date: September 11, 2026
Status: Not started
Assignee: Alex

Every item in your to do database table has a page that you can edit with content blocks (things like text, bullets, images etc.) - it’s just like editing any other document.

Try the following:

- [ ]  Click anywhere and start typing
- [ ]  Type the `/` key to add all kinds of content — headers, pages, etc.
    
    (Here’s an [Example sub-page](Click%20me%20to%20see%20even%20more%20detail/Example%20sub-page%20925dcac1a06854b8ba192662b98382d5.md)!)
    
- [ ]  Hover over this line, click and hold the : then drag to move it around

<aside>
<img src="https://fixture.example.test/icons/notion_gray.svg" alt="https://fixture.example.test/icons/notion_gray.svg" width="40px" />

This Database is configured as a Tasks database which allows its contents to appear on your Home tab. All tasks will make their way there. 

https://fixture.example.test/help/guides/give-your-to-dos-a-home-with-task-databases

</aside>